# Retail Customer Segmentation & Churn Analysis

## Project Overview
A SQL-based retail/e-commerce analytics project that converts customer transaction data into RFM segments, repeat-purchase metrics, average basket analysis, cohort retention tables, and churn-risk groups.

**Role:** Business & Data Analyst  
**Domain:** Retail / E-commerce  
**Tools:** PostgreSQL SQL, Power BI-ready outputs, Excel/CSV  
**Dataset:** Synthetic data generated for portfolio use

## Business Problem
The business has customer, order, and product data but lacks a structured view of customer value and retention. The analysis answers:
- Who are the highest-value customers?
- Which customers are at risk of becoming inactive?
- What is the repeat purchase rate?
- What is the average basket value?
- Which acquisition cohorts retain customers?
- Where is customer leakage most visible?

## Data Model
- `customers`: customer profile and signup information
- `orders`: transactional order lines
- `products`: product/category attributes

## SQL Techniques Demonstrated
- CTEs
- `NTILE()`
- Window functions
- `CASE`
- Self-joins
- `DATE_TRUNC()`
- Aggregations
- Conditional aggregation
- Cohort logic
- Customer-level feature engineering

## Analysis Flow
Raw Data → Data Quality → Customer Metrics → RFM Scoring → Segmentation → Repeat Purchase → Basket Analysis → Cohort Retention → Churn Risk → Business Recommendations

## RFM Framework
**Recency:** days since last purchase  
**Frequency:** number of distinct orders  
**Monetary:** total customer revenue

Five quantile groups are created with `NTILE(5)`.

## Segment Framework
- Champions
- Loyal Customers
- Potential Loyalists
- At Risk
- Hibernating
- New Customers
- Other

## Churn Framework
For this portfolio project, inactivity is grouped as:
- 0–30 days: Active
- 31–60 days: Watch
- 61–90 days: High Risk
- >90 days: Inactive

These thresholds are illustrative and should be calibrated to the normal purchase cycle in a real business.

## Business Recommendations
- Use RFM segments to prioritize retention campaigns.
- Trigger second-purchase journeys for one-time customers.
- Use win-back campaigns for high-value inactive customers.
- Investigate cohorts with sharp month-over-month retention drops.
- Use category-level basket analysis to identify cross-sell opportunities.

## Power BI Dashboard
Recommended pages:
1. Executive Customer Overview
2. RFM Segmentation
3. Cohort Retention & Churn

Suggested KPIs:
- Total Customers
- Active Customers
- Repeat Purchase Rate
- Average Basket Value
- Total Revenue
- At-Risk Customers

## Repository Structure
```text
Retail-Customer-Segmentation-Churn-SQL/
├── data/
│   ├── customers.csv
│   ├── orders.csv
│   └── products.csv
├── sql/
│   ├── 01_data_quality.sql
│   ├── 02_customer_metrics.sql
│   ├── 03_rfm_analysis.sql
│   ├── 04_customer_segmentation.sql
│   ├── 05_repeat_purchase.sql
│   ├── 06_basket_analysis.sql
│   ├── 07_cohort_analysis.sql
│   └── 08_churn_analysis.sql
├── documentation/
│   └── project_report.md
└── powerbi/
    └── README.md
```

## Resume Entry
**Retail Customer Segmentation & Churn Analysis | SQL + Power BI**
- Analyzed retail customer, order, and product data using SQL to develop RFM-based customer segmentation and identify high-value, loyal, new, at-risk, and inactive customer groups.
- Applied `NTILE()`, `CASE`, CTEs, window functions, self-joins, and `DATE_TRUNC()` to calculate RFM scores, repeat purchase rate, average basket value, cohort retention, and churn risk.
- Prepared Power BI-ready analytical outputs to visualize customer segments, retention trends, revenue contribution, repeat purchasing, and customer leakage.

## Interview Talking Point
"I built this project to understand customer retention from a business analyst perspective. I started with transactional data, validated the data quality, engineered customer-level RFM metrics, segmented customers using SQL window functions, then analyzed repeat purchasing and cohort retention. Finally, I translated the findings into targeted retention actions and a Power BI dashboard design."
