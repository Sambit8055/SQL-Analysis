# Power BI Build Guide

Import `customers.csv`, `orders.csv`, and `products.csv`.

Recommended relationships:
- customers[customer_id] 1 → * orders[customer_id]
- products[product_id] 1 → * orders[product_id]

Create SQL-derived tables/views for RFM, cohort retention and churn risk, then use those outputs as dashboard sources.

Recommended pages:
1. Executive Overview
2. RFM Segmentation
3. Cohort Retention & Churn
