-- 05_repeat_purchase.sql
WITH customer_orders AS (
    SELECT customer_id, COUNT(DISTINCT order_id) AS order_count
    FROM orders
    GROUP BY customer_id
)
SELECT
    COUNT(*) AS total_customers,
    SUM(CASE WHEN order_count >= 2 THEN 1 ELSE 0 END) AS repeat_customers,
    ROUND(
        100.0 * SUM(CASE WHEN order_count >= 2 THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS repeat_purchase_rate_pct
FROM customer_orders;

-- Repeat purchase rate by acquisition month
WITH first_purchase AS (
    SELECT customer_id, DATE_TRUNC('month', MIN(order_date)) AS cohort_month
    FROM orders GROUP BY customer_id
),
orders_per_customer AS (
    SELECT customer_id, COUNT(DISTINCT order_id) AS order_count
    FROM orders GROUP BY customer_id
)
SELECT fp.cohort_month,
       COUNT(*) AS customers,
       SUM(CASE WHEN opc.order_count >= 2 THEN 1 ELSE 0 END) AS repeat_customers,
       ROUND(100.0 * SUM(CASE WHEN opc.order_count >= 2 THEN 1 ELSE 0 END)/COUNT(*),2)
          AS repeat_purchase_rate_pct
FROM first_purchase fp
JOIN orders_per_customer opc ON fp.customer_id=opc.customer_id
GROUP BY fp.cohort_month
ORDER BY fp.cohort_month;
