-- 08_churn_analysis.sql
WITH last_purchase AS (
    SELECT customer_id, MAX(order_date) AS last_purchase_date,
           COUNT(DISTINCT order_id) AS order_count,
           SUM(total_amount) AS lifetime_value
    FROM orders
    GROUP BY customer_id
)
SELECT
    customer_id,
    last_purchase_date,
    (DATE '2025-12-31' - last_purchase_date) AS recency_days,
    order_count,
    ROUND(lifetime_value,2) AS lifetime_value,
    CASE
        WHEN DATE '2025-12-31' - last_purchase_date > 90 THEN 'Inactive >90 Days'
        WHEN DATE '2025-12-31' - last_purchase_date > 60 THEN 'High Risk'
        WHEN DATE '2025-12-31' - last_purchase_date > 30 THEN 'Watch'
        ELSE 'Active'
    END AS churn_risk
FROM last_purchase
ORDER BY recency_days DESC;
