-- 03_rfm_analysis.sql
WITH rfm AS (
    SELECT
        customer_id,
        (DATE '2025-12-31' - MAX(order_date)) AS recency_days,
        COUNT(DISTINCT order_id) AS frequency,
        SUM(total_amount) AS monetary
    FROM orders
    GROUP BY customer_id
),
scores AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recency_days DESC) AS recency_score,
        NTILE(5) OVER (ORDER BY frequency ASC) AS frequency_score,
        NTILE(5) OVER (ORDER BY monetary ASC) AS monetary_score
    FROM rfm
)
SELECT *,
       CONCAT(recency_score, frequency_score, monetary_score) AS rfm_score
FROM scores;
