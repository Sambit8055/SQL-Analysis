-- 02_customer_metrics.sql
WITH customer_metrics AS (
    SELECT
        customer_id,
        MAX(order_date) AS last_purchase_date,
        MIN(order_date) AS first_purchase_date,
        COUNT(DISTINCT order_id) AS frequency,
        SUM(total_amount) AS monetary,
        COUNT(DISTINCT product_id) AS distinct_products
    FROM orders
    GROUP BY customer_id
)
SELECT
    c.customer_id,
    c.city,
    cm.first_purchase_date,
    cm.last_purchase_date,
    (DATE '2025-12-31' - cm.last_purchase_date) AS recency_days,
    cm.frequency,
    ROUND(cm.monetary, 2) AS monetary,
    cm.distinct_products
FROM customer_metrics cm
JOIN customers c ON c.customer_id = cm.customer_id;
