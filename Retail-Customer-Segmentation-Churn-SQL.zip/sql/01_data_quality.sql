-- 01_data_quality.sql
-- PostgreSQL syntax

-- Duplicate orders
SELECT order_id, COUNT(*) AS duplicate_count
FROM orders
GROUP BY order_id
HAVING COUNT(*) > 1;

-- Missing customer/product references
SELECT COUNT(*) AS missing_customer_ids
FROM orders o LEFT JOIN customers c ON o.customer_id=c.customer_id
WHERE c.customer_id IS NULL;

SELECT COUNT(*) AS missing_product_ids
FROM orders o LEFT JOIN products p ON o.product_id=p.product_id
WHERE p.product_id IS NULL;

-- Invalid transaction values
SELECT COUNT(*) AS invalid_orders
FROM orders
WHERE quantity <= 0 OR unit_price <= 0 OR total_amount <= 0;

-- Revenue validation
SELECT COUNT(*) AS revenue_mismatches
FROM orders
WHERE ABS(total_amount - quantity * unit_price) > 0.01;
