-- 07_cohort_analysis.sql
WITH first_purchase AS (
    SELECT customer_id, DATE_TRUNC('month', MIN(order_date)) AS cohort_month
    FROM orders
    GROUP BY customer_id
),
cohort_activity AS (
    SELECT DISTINCT
        o.customer_id,
        fp.cohort_month,
        DATE_TRUNC('month', o.order_date) AS purchase_month
    FROM orders o
    JOIN first_purchase fp ON o.customer_id=fp.customer_id
),
cohort_counts AS (
    SELECT cohort_month,
           purchase_month,
           COUNT(DISTINCT customer_id) AS active_customers,
           (
             (EXTRACT(YEAR FROM purchase_month) - EXTRACT(YEAR FROM cohort_month))*12
             + EXTRACT(MONTH FROM purchase_month) - EXTRACT(MONTH FROM cohort_month)
           )::int AS month_number
    FROM cohort_activity
    GROUP BY cohort_month,purchase_month
),
cohort_size AS (
    SELECT cohort_month, COUNT(DISTINCT customer_id) AS cohort_customers
    FROM first_purchase
    GROUP BY cohort_month
)
SELECT cc.cohort_month,
       cc.month_number,
       cc.active_customers,
       cs.cohort_customers,
       ROUND(100.0*cc.active_customers/cs.cohort_customers,2) AS retention_pct
FROM cohort_counts cc
JOIN cohort_size cs USING (cohort_month)
ORDER BY cc.cohort_month, cc.month_number;
