-- 04_customer_segmentation.sql
WITH rfm AS (
    SELECT
        customer_id,
        (DATE '2025-12-31' - MAX(order_date)) AS recency_days,
        COUNT(DISTINCT order_id) AS frequency,
        SUM(total_amount) AS monetary
    FROM orders
    GROUP BY customer_id
),
scores AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recency_days DESC) AS recency_score,
        NTILE(5) OVER (ORDER BY frequency ASC) AS frequency_score,
        NTILE(5) OVER (ORDER BY monetary ASC) AS monetary_score
    FROM rfm
)
SELECT *,
    CASE
        WHEN recency_score >= 4 AND frequency_score >= 4 AND monetary_score >= 4
            THEN 'Champions'
        WHEN frequency_score >= 4 AND recency_score >= 3
            THEN 'Loyal Customers'
        WHEN recency_score >= 4 AND frequency_score >= 3
            THEN 'Potential Loyalists'
        WHEN recency_score <= 2 AND monetary_score >= 4
            THEN 'At Risk'
        WHEN recency_score <= 2 AND frequency_score <= 2 AND monetary_score <= 2
            THEN 'Hibernating'
        WHEN recency_days <= 45 AND frequency = 1
            THEN 'New Customers'
        ELSE 'Other'
    END AS customer_segment,
    CASE
        WHEN recency_days > 90 THEN 'At Risk / Inactive'
        ELSE 'Active'
    END AS customer_status
FROM scores;
