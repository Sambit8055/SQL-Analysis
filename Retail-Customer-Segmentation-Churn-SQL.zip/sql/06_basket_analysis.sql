-- 06_basket_analysis.sql
SELECT
    ROUND(SUM(total_amount) / COUNT(DISTINCT order_id), 2) AS average_basket_value,
    ROUND(SUM(quantity)::numeric / COUNT(DISTINCT order_id), 2) AS average_units_per_order
FROM orders;

SELECT
    p.category,
    COUNT(DISTINCT o.order_id) AS orders,
    ROUND(SUM(o.total_amount),2) AS revenue,
    ROUND(SUM(o.total_amount)/COUNT(DISTINCT o.order_id),2) AS avg_basket_value
FROM orders o
JOIN products p ON o.product_id=p.product_id
GROUP BY p.category
ORDER BY revenue DESC;
