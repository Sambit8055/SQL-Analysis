# Project Report — Retail/E-commerce Customer Segmentation and Churn

## 1. Executive Summary
This project analyzes retail/e-commerce transaction data to understand customer value, purchasing behavior and retention. SQL is used as the primary analytical layer. The project creates customer-level RFM metrics, segments customers, measures repeat purchase behavior and average basket size, and builds a cohort retention framework.

## 2. Business Objective
The business needs a repeatable method to identify valuable customers, detect customers whose engagement is weakening, understand cohort leakage and support retention campaigns.

## 3. Dataset
The portfolio dataset contains:
- 500 customers
- Product master data across Electronics, Home, Fashion, Beauty and Grocery
- Transactional orders across 2025

The dataset is synthetic and intended for learning, portfolio and demonstration purposes.

## 4. Methodology
1. Validate transaction and master data.
2. Aggregate orders to customer level.
3. Calculate Recency, Frequency and Monetary value.
4. Score customers using NTILE(5).
5. Create business segments using CASE logic.
6. Calculate repeat purchase rate.
7. Calculate average basket value and units per order.
8. Identify customer cohorts by first purchase month.
9. Calculate month-by-month cohort retention.
10. Classify customers by churn risk based on recency.
11. Translate analytical outputs into retention actions.

## 5. Key SQL Concepts
### NTILE
Used to distribute customers into five quantile groups for RFM scoring.

### CASE
Used to translate numeric scores into business-friendly segments and churn-risk categories.

### DATE_TRUNC
Used to normalize purchase dates to month-level cohorts.

### Self-Join
Used to compare successive purchases and support purchase-gap analysis.

### CTEs
Used to keep multi-stage analytical logic readable and reusable.

## 6. RFM Segmentation
The RFM framework evaluates:
- Recency — how recently a customer purchased
- Frequency — how often the customer purchases
- Monetary — how much the customer spends

Business segments include Champions, Loyal Customers, Potential Loyalists, At Risk, Hibernating and New Customers.

## 7. Retention Analysis
Customers are grouped according to their first purchase month. For every cohort, the project measures the percentage of customers who remain active in subsequent months.

A steep decline between Month 0 and Month 1 can indicate weak early retention. A continuing decline in later months can indicate longer-term leakage.

## 8. Churn Analysis
The portfolio model uses recency bands:
- Active: 0–30 days
- Watch: 31–60 days
- High Risk: 61–90 days
- Inactive: >90 days

The thresholds are examples and should be validated against the company's actual purchase cycle.

## 9. Business Action Matrix
| Segment | Business Action |
|---|---|
| Champions | Loyalty/VIP engagement |
| Loyal Customers | Cross-sell and upsell |
| Potential Loyalists | Personalized recommendations |
| New Customers | Second-purchase journey |
| At Risk | Win-back campaign |
| Hibernating | Reactivation campaign |
| Inactive | Low-cost re-engagement or suppression |

## 10. Dashboard Design
### Page 1: Executive Overview
KPIs, monthly revenue, customer count, repeat purchase rate and average basket value.

### Page 2: RFM
Segment distribution, revenue by segment, customer value scatterplots and segment trends.

### Page 3: Cohort Retention
Retention heatmap, cohort size, monthly retention and churn-risk trend.

## 11. Expected Outcome
The project gives the business a structured customer-retention framework rather than treating every customer equally. It enables marketing and customer-success teams to prioritize actions using customer value, engagement and historical behavior.

## 12. Limitations
- Dataset is synthetic.
- Churn thresholds are illustrative.
- RFM quantiles depend on the selected analysis population and period.
- Purchase behavior can vary substantially by product category.
- Correlation in transaction data does not establish the causal reason for churn.

## 13. Future Enhancements
- Add customer lifetime value (CLV).
- Add product affinity and market-basket analysis.
- Build automated monthly cohort refresh.
- Add Power BI drill-through pages.
- Develop a churn prediction model using Python.
- Add campaign-response tracking and A/B testing.

